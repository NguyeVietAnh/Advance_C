#include <stdio.h>
#include <math.h>

int main()
{
    float r;

    r = sqrt(2.0);

	printf("The square root of 2 is %f\n",r);

	return(0);
}
