#include <stdio.h>

int main()
{
	int age;

	age = 30;
	printf("The C language is over %d years old!\n",age);

	return(0);
}

