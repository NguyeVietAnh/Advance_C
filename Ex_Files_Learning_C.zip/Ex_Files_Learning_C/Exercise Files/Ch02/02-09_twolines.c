#include <stdio.h>

int main()
{
    printf("This is line 1
          This is line 2");


    return(0);
}
