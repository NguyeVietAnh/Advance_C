/************************\
|* This code written by *|
|*     the brilliant    *|
|*      Dan Gookin      *|
\************************/
#include <stdio.h>

//************** MAIN FUNCTION **************//
int main()
{
    /* These puts() statements send text to
       the standard output device */
	puts("I'm a computer!");
	puts("Thrilled to meet you!");

	/* I give nothing back to the OS */
	return(0);
}

//===========================================//
//                 END                       //
//===========================================//
