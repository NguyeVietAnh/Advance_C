#include <stdio.h>

int main()
{
    printf("This is line 1\nThis is line 2\n");

    return(0);
}
