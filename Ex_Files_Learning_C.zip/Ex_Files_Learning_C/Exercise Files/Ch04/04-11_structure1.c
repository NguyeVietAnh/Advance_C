#include <stdio.h>

int main()
{
	struct bank {
		int account;
		float balance;
	};

	return(0);
}

